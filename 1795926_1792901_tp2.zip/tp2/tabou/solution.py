class Solution:
    tourSolution = []
    hauteurSolution = 0